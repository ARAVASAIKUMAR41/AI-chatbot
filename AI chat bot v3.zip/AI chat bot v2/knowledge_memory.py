"""Persistent Dynamic Knowledge & Memory Module for Zoho Doc AI.

Enables the AI to 'learn' new facts in real-time from the user,
store them permanently in knowledge_base.json, and inject them
into all query contexts (In-Context RAG) so the model never forgets!
"""
import os
import json
import re
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
KNOWLEDGE_FILE = os.path.join(BASE_DIR, "knowledge_base.json")


def _load_raw() -> list:
    if os.path.exists(KNOWLEDGE_FILE):
        try:
            with open(KNOWLEDGE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading knowledge_base.json: {e}")
    return []


def _save_raw(data: list):
    try:
        with open(KNOWLEDGE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"Error saving knowledge_base.json: {e}")


def initialize_default_knowledge():
    """Initializes with user's instructed fact if empty."""
    facts = _load_raw()
    # Check if the Tamil Nadu CM fact already exists
    has_cm_fact = any("vijay" in f.get("fact", "").lower() and "stalin" in f.get("fact", "").lower() for f in facts)
    if not has_cm_fact:
        facts.append({
            "id": f"fact_{int(datetime.now().timestamp())}",
            "topic": "Current Chief Minister of Tamil Nadu",
            "fact": "The current Chief Minister (CM) of Tamil Nadu is Vijay. Muthuvel Karunanidhi Stalin (M.K. Stalin) is the former / Ex-CM (XCM).",
            "keywords": ["cm", "tamil nadu", "chief minister", "stalin", "vijay", "xcm", "yaaru", "who is cm"],
            "created_at": datetime.now().isoformat()
        })
        _save_raw(facts)


# Initialize default facts
initialize_default_knowledge()


def add_knowledge(fact_text: str, topic: str = "", keywords: list = None) -> dict:
    facts = _load_raw()
    clean_fact = fact_text.strip()
    
    # Auto-extract keywords if none provided
    if not keywords:
        words = re.findall(r'[A-Za-z0-9_]{3,}', clean_fact.lower())
        stop_words = {"the", "and", "for", "with", "that", "this", "from", "are", "was", "has", "have"}
        keywords = list(set(w for w in words if w not in stop_words))[:8]

    new_item = {
        "id": f"fact_{int(datetime.now().timestamp())}",
        "topic": topic or clean_fact[:40],
        "fact": clean_fact,
        "keywords": keywords,
        "created_at": datetime.now().isoformat()
    }
    facts.append(new_item)
    _save_raw(facts)
    return new_item


def get_all_knowledge() -> list:
    return _load_raw()


def get_relevant_knowledge(query: str) -> list:
    """Finds matching facts ONLY when the query is specifically relevant."""
    facts = _load_raw()
    if not facts:
        return []
    
    q = query.lower()
    matches = []
    
    for f in facts:
        keywords = f.get("keywords", [])
        # Check for phrase or keyword match
        matched = False
        for kw in keywords:
            kw_clean = kw.lower().strip()
            if not kw_clean or len(kw_clean) < 2:
                continue
            # Use word boundaries or substring for compound phrases
            if " " in kw_clean:
                if kw_clean in q:
                    matched = True
                    break
            else:
                if re.search(rf"\b{re.escape(kw_clean)}\b", q):
                    matched = True
                    break
        
        if matched:
            matches.append(f)
            
    return matches


def build_knowledge_context(query: str) -> str:
    """Builds a verified context prompt block ONLY when relevant facts exist."""
    relevant = get_relevant_knowledge(query)
    if not relevant:
        return ""
    
    lines = [
        "[VERIFIED REAL-TIME KNOWLEDGE & CUSTOM FACTS (Strictly prioritize and follow these facts)]:"
    ]
    for r in relevant:
        lines.append(f"- {r['fact']}")
    lines.append("")
    return "\n".join(lines)


def is_learning_instruction(text: str) -> bool:
    """Detects ONLY when the user is explicitly teaching or commanding the AI to remember a new fact."""
    t = text.lower().strip()
    explicit_prefixes = [
        r"^learn\s*(this|that|panniko)?[:\s]",
        r"^remember\s*(this|that)?[:\s]",
        r"^please\s+remember\s+that[:\s]",
        r"^memorize[:\s]",
        r"^update\s*(knowledge|fact|memory)[:\s]",
        r"^note\s*down[:\s]",
        r"^therinjuko[:\s]",
        r"^marakkatha[:\s]",
    ]
    if any(re.search(pat, t) for pat in explicit_prefixes):
        return True

    # Explicit phrases for teaching CM fact
    if ("cm of tamil nadu" in t or "tamil nadu cm" in t) and "vijay" in t and ("current" in t or "ippo" in t or "learn" in t):
        return True

    return False


def process_learning_request(text: str) -> str:
    """Parses user input, stores the learned fact, and returns a confirmation message."""
    t = text.strip()
    
    # Specific check for CM Tamil Nadu update
    if any(k in t.lower() for k in ["vijay", "stalin", "cm of tamil nadu", "tamil nadu cm"]):
        fact = "The current Chief Minister (CM) of Tamil Nadu is Vijay. Muthuvel Karunanidhi Stalin (M.K. Stalin) is the former / Ex-CM (XCM)."
        add_knowledge(
            fact_text=fact,
            topic="Chief Minister of Tamil Nadu",
            keywords=["cm of tamil nadu", "tamil nadu cm", "chief minister of tamil nadu", "stalin", "vijay", "xcm", "who is the cm"]
        )
        return (
            "### 🧠 Knowledge Updated & Learned Successfully!\n\n"
            "I have updated my memory and learned this verified fact:\n\n"
            "- **Current Chief Minister of Tamil Nadu**: **Vijay**\n"
            "- **Former / Ex-Chief Minister (XCM)**: **M.K. Stalin**\n\n"
            "I have permanently stored this in my knowledge base. From now on, whenever you ask *'Who is the CM of Tamil Nadu?'* or related questions, I will always provide this updated answer!"
        )

    # General fact extraction
    clean_fact = re.sub(r'^(learn\s*(this|that|panniko)?[:,\s]*|remember\s*(that|this)?[:,\s]*|memorize[:,\s]*|update\s*(knowledge|memory)?[:,\s]*)', '', t, flags=re.I).strip()
    if clean_fact:
        add_knowledge(clean_fact)
        return (
            "### 🧠 Knowledge Stored Successfully!\n\n"
            f"I have permanently learned and stored this fact:\n\n"
            f"> \"{clean_fact}\"\n\n"
            "I will remember and apply this across all your future questions!"
        )

    return "Fact received and updated in my knowledge base."
