import io
import re
import base64
import textwrap
from PIL import Image as PILImage

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, Preformatted, HRFlowable, Image as RLImage
from reportlab.lib import colors

from zoho_parser import format_deluge_code


def set_cell_background(cell, fill_hex: str):
    """Sets background color of a docx table cell."""
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tc_pr.append(shd)


def set_cell_border(cell, color_hex="CBD5E1", sz="4", val="single"):
    """Sets a subtle border on a docx table cell."""
    tc_pr = cell._tc.get_or_add_tcPr()
    tcBorders = parse_xml(f'''
        <w:tcBorders {nsdecls("w")}>
            <w:top w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color_hex}"/>
            <w:left w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color_hex}"/>
            <w:bottom w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color_hex}"/>
            <w:right w:val="{val}" w:sz="{sz}" w:space="0" w:color="{color_hex}"/>
        </w:tcBorders>
    ''')
    tc_pr.append(tcBorders)


def sanitize_export_text(text: str) -> str:
    """Removes emojis, variation selectors, zero-width spaces, and unexpanded tabs
    to completely eliminate black dots/squares in exported Word and PDF documents.
    """
    if not text:
        return ""
    t = re.sub(r'[\U00010000-\U0010ffff]', '', text)
    t = re.sub(r'[\u2600-\u27bf\ufe00-\ufe0f]', '', t)
    t = t.replace('\u00a0', ' ').replace('\t', '    ')
    t = re.sub(r'[\u200b-\u200f\u202a-\u202e]', '', t)
    return t


def decode_base64_image(img_data: str) -> bytes:
    """Decodes data:image/png;base64,... or raw base64 string to bytes."""
    if not img_data:
        raise ValueError("Empty image data")
    if "," in img_data:
        img_data = img_data.split(",", 1)[1]
    cleaned = "".join(img_data.split())
    return base64.b64decode(cleaned)


def clean_and_format_code(lines: list, lang: str = "") -> str:
    """Expands tabs to 4 spaces, strips non-breaking spaces, and normalizes Deluge indentation.
    Completely eliminates any tab characters that cause black dots/squares in Word and PDF viewers.
    """
    if not lines:
        return ""
    expanded = [l.expandtabs(4).replace('\u00a0', ' ') for l in lines]
    while expanded and not expanded[0].strip():
        expanded.pop(0)
    while expanded and not expanded[-1].strip():
        expanded.pop()
    if not expanded:
        return ""

    joined = "\n".join(expanded)
    if lang in ("deluge", "ds") or any("input." in l or "zoho." in l or "thisapp." in l for l in expanded):
        return format_deluge_code(joined)

    # Standard common dedent for generic languages
    non_empty = [l for l in expanded if l.strip()]
    if non_empty:
        common = min(len(l) - len(l.lstrip()) for l in non_empty)
        if common > 0:
            return "\n".join(l[common:] if len(l) >= common else l.lstrip() for l in expanded)
    return joined


def find_matching_diagram(mermaid_idx: int, code_lines: list, diagrams: list):
    """Finds matching diagram from frontend payload by index or code match."""
    if not diagrams or not isinstance(diagrams, list):
        return None
    raw_code = "\n".join(code_lines).strip()
    # 1. Match by exact index
    for d in diagrams:
        if isinstance(d, dict) and d.get("index") == mermaid_idx and d.get("image"):
            return d
    # 2. Match by raw code content
    for d in diagrams:
        if isinstance(d, dict) and d.get("image"):
            d_raw = (d.get("raw") or "").strip()
            if d_raw and (d_raw == raw_code or d_raw in raw_code or raw_code in d_raw):
                return d
    # 3. Direct positional fallback
    if 0 <= mermaid_idx < len(diagrams):
        d = diagrams[mermaid_idx]
        if isinstance(d, dict) and d.get("image"):
            return d
    return None


def parse_mermaid_summary(mermaid_code: str):
    """Parses a mermaid flowchart into structured stages, nodes, and flow transitions for fallback display."""
    lines = [l.strip() for l in mermaid_code.splitlines() if l.strip()]
    stages = []
    transitions = []
    current_stage = "System Process Flow"
    current_nodes = []
    node_labels = {}

    for line in lines:
        if line.startswith("flowchart") or line.startswith("graph") or line.startswith("classDef") or line.startswith("class "):
            continue
        sub_m = re.search(r'subgraph\s+([A-Za-z0-9_]+)\s*(?:\["([^"]+)"\])?', line)
        if sub_m:
            if current_nodes:
                stages.append((current_stage, current_nodes))
                current_nodes = []
            current_stage = sub_m.group(2) or sub_m.group(1)
            continue
        if line == "end":
            if current_nodes:
                stages.append((current_stage, current_nodes))
                current_nodes = []
            current_stage = "System Process Flow"
            continue

        node_m = re.findall(r'([A-Za-z0-9_]+)\s*(?:\["([^"]+)"\]|\{\{"([^"]+)"\}\}|\(\["([^"]+)"\]\)|\(\("([^"]+)"\)\)|\[\(([^"]+)\)\])', line)
        for nm in node_m:
            nid = nm[0]
            label = next((x for x in nm[1:] if x), nid)
            node_labels[nid] = label
            if label not in current_nodes:
                current_nodes.append(label)

        edge_m = re.search(r'([A-Za-z0-9_]+)\s*(?:-->|-\.->|==>)\s*(?:\|([^|]+)\|)?\s*([A-Za-z0-9_]+)', line)
        if edge_m:
            src_id = edge_m.group(1)
            edge_lbl = edge_m.group(2) or "progresses to"
            dst_id = edge_m.group(3)
            src_name = node_labels.get(src_id, src_id)
            dst_name = node_labels.get(dst_id, dst_id)
            transitions.append((src_name, edge_lbl, dst_name))

    if current_nodes:
        stages.append((current_stage, current_nodes))

    return stages, transitions


def render_mermaid_fallback_docx(doc, code_lines):
    """Renders a structured process table in Word when no diagram image is provided."""
    raw_code = "\n".join(code_lines)
    stages, transitions = parse_mermaid_summary(raw_code)

    tp = doc.add_paragraph()
    tp.paragraph_format.space_before = Pt(8)
    tp.paragraph_format.space_after = Pt(4)
    r = tp.add_run("Architecture Workflow Flowchart Summary")
    r.font.bold = True
    r.font.size = Pt(10.5)
    r.font.color.rgb = RGBColor(15, 23, 42)

    rows = [["Component / Stage", "Type / Layer", "Action & Flow Destination"]]
    if transitions:
        for src, edge, dst in transitions:
            rows.append([src, "Process Flow Step", f"Progresses to: {dst} ({edge})"])
    elif stages:
        for st_name, nodes in stages:
            rows.append([st_name, "Architectural Group", ", ".join(nodes)])
    else:
        rows.append(["Application Lifecycle", "Process Automation", "System workflow execution path"])

    tbl = doc.add_table(rows=len(rows), cols=3)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tbl.autofit = True
    for r_idx, r_data in enumerate(rows):
        row = tbl.rows[r_idx]
        is_h = (r_idx == 0)
        for c_idx, val in enumerate(r_data):
            cell = row.cells[c_idx]
            cell.text = val
            if is_h:
                set_cell_background(cell, "1E293B")
                for p in cell.paragraphs:
                    for run in p.runs:
                        run.font.bold = True
                        run.font.color.rgb = RGBColor(255, 255, 255)
                        run.font.size = Pt(9.0)
            else:
                bg = "F8FAFC" if r_idx % 2 == 1 else "FFFFFF"
                set_cell_background(cell, bg)
                for p in cell.paragraphs:
                    for run in p.runs:
                        run.font.size = Pt(8.5)
    doc.add_paragraph()


def markdown_to_docx(markdown_text: str, diagrams: list = None) -> io.BytesIO:
    """Converts Markdown text into a styled, professional Word document with clean Deluge code cards and embedded flowchart diagrams."""
    markdown_text = sanitize_export_text(markdown_text)
    doc = Document()

    # Set standard margins (1 inch)
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)

    lines = markdown_text.splitlines()
    in_code_block = False
    code_lines = []
    code_lang = ""
    mermaid_counter = 0
    in_table = False
    table_lines = []

    def flush_table():
        nonlocal in_table, table_lines
        if not table_lines:
            return
        rows = []
        for line in table_lines:
            if re.match(r'^\s*\|?\s*:?-+:?\s*\|', line):
                continue
            cells = [c.strip() for c in line.strip('|').split('|')]
            if cells:
                rows.append(cells)
        if rows:
            max_cols = max(len(r) for r in rows)
            table = doc.add_table(rows=len(rows), cols=max_cols)
            table.alignment = WD_TABLE_ALIGNMENT.CENTER
            table.autofit = True

            for r_idx, row_data in enumerate(rows):
                row = table.rows[r_idx]
                is_header = (r_idx == 0)
                for c_idx, cell_value in enumerate(row_data):
                    if c_idx < max_cols:
                        cell = row.cells[c_idx]
                        cell.text = cell_value.replace('`', '')
                        if is_header:
                            set_cell_background(cell, "1E293B")
                            for p in cell.paragraphs:
                                for run in p.runs:
                                    run.font.bold = True
                                    run.font.color.rgb = RGBColor(255, 255, 255)
                                    run.font.size = Pt(9.5)
                        else:
                            bg = "F8FAFC" if r_idx % 2 == 1 else "FFFFFF"
                            set_cell_background(cell, bg)
                            for p in cell.paragraphs:
                                for run in p.runs:
                                    run.font.size = Pt(9)
            doc.add_paragraph()
        table_lines = []
        in_table = False

    def flush_code():
        nonlocal in_code_block, code_lines, code_lang, mermaid_counter
        if not code_lines and code_lang != "mermaid":
            in_code_block = False
            return

        if code_lang == "mermaid":
            matched_diag = find_matching_diagram(mermaid_counter, code_lines, diagrams)
            mermaid_counter += 1
            if matched_diag and matched_diag.get("image"):
                try:
                    img_bytes = decode_base64_image(matched_diag["image"])
                    p = doc.add_paragraph()
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    p.paragraph_format.space_before = Pt(8)
                    p.paragraph_format.space_after = Pt(2)
                    run = p.add_run()
                    run.add_picture(io.BytesIO(img_bytes), width=Inches(6.2))

                    cap = doc.add_paragraph()
                    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    cap.paragraph_format.space_before = Pt(2)
                    cap.paragraph_format.space_after = Pt(10)
                    cap_run = cap.add_run("Figure: Interactive Architecture Process & Lifecycle Flowchart")
                    cap_run.font.size = Pt(8.5)
                    cap_run.font.italic = True
                    cap_run.font.color.rgb = RGBColor(100, 116, 139)

                    code_lines = []
                    in_code_block = False
                    return
                except Exception as img_err:
                    print(f"Error embedding chart image in DOCX: {img_err}", flush=True)

            # Fallback if no image available: render structured table instead of raw code
            render_mermaid_fallback_docx(doc, code_lines)
            code_lines = []
            in_code_block = False
            return

        # Clean, indent, and format non-mermaid code block (zero tabs, zero black dots)
        formatted_code = clean_and_format_code(code_lines, code_lang)
        if formatted_code:
            # User rule: "Docx writer: put code in code-styled paragraphs (monospace, shaded), not inside table cells."
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(6)
            p.paragraph_format.space_after = Pt(6)
            p.paragraph_format.left_indent = Inches(0.25)
            p.paragraph_format.right_indent = Inches(0.25)

            # Apply paragraph shading in docx (XML w:shd)
            try:
                from docx.oxml import OxmlElement
                from docx.oxml.ns import qn
                pPr = p._p.get_or_add_pPr()
                shd = OxmlElement('w:shd')
                shd.set(qn('w:val'), 'clear')
                shd.set(qn('w:color'), 'auto')
                shd.set(qn('w:fill'), 'F1F5F9')
                pPr.append(shd)
            except Exception:
                pass

            run = p.add_run(formatted_code)
            run.font.name = "Consolas"
            run.font.size = Pt(8.5)
            run.font.color.rgb = RGBColor(15, 23, 42)

            doc.add_paragraph()

        code_lines = []
        in_code_block = False

    for line in lines:
        stripped = line.strip()

        # Handle code blocks
        if stripped.startswith("```"):
            if in_code_block:
                flush_code()
            else:
                if in_table:
                    flush_table()
                in_code_block = True
                code_lang = stripped[3:].strip().lower()
                code_lines = []
            continue

        if in_code_block:
            code_lines.append(line)
            continue

        # Handle tables
        if stripped.startswith("|") and stripped.endswith("|"):
            in_table = True
            table_lines.append(stripped)
            continue
        elif in_table:
            flush_table()

        if not stripped:
            continue

        # Headings
        if stripped.startswith("# "):
            p = doc.add_heading(stripped[2:].strip(), level=1)
            p.paragraph_format.space_before = Pt(14)
            p.paragraph_format.space_after = Pt(6)
        elif stripped.startswith("## "):
            p = doc.add_heading(stripped[3:].strip(), level=2)
            p.paragraph_format.space_before = Pt(12)
            p.paragraph_format.space_after = Pt(4)
        elif stripped.startswith("### "):
            p = doc.add_heading(stripped[4:].strip(), level=3)
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.space_after = Pt(2)
        elif stripped.startswith("- ") or stripped.startswith("* "):
            p = doc.add_paragraph(style='List Bullet')
            _add_formatted_runs(p, stripped[2:].strip())
        elif re.match(r'^\d+\.\s+', stripped):
            p = doc.add_paragraph(style='List Number')
            content = re.sub(r'^\d+\.\s+', '', stripped)
            _add_formatted_runs(p, content)
        else:
            p = doc.add_paragraph()
            _add_formatted_runs(p, stripped)

    if in_table:
        flush_table()
    if in_code_block:
        flush_code()

    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer


def _add_formatted_runs(paragraph, text: str):
    """Processes markdown bold and inline code in paragraph text."""
    parts = re.split(r'(\*\*[^*]+\*\*|`[^`]+`)', text)
    for part in parts:
        if part.startswith("**") and part.endswith("**"):
            run = paragraph.add_run(part[2:-2])
            run.font.bold = True
        elif part.startswith("`") and part.endswith("`"):
            run = paragraph.add_run(part[1:-1])
            run.font.name = "Consolas"
            run.font.size = Pt(9.5)
            run.font.color.rgb = RGBColor(15, 23, 42)
        else:
            paragraph.add_run(part)


def _format_inline_pdf_markdown(text: str, is_header: bool = False) -> str:
    """Escapes XML and converts markdown inline syntax into ReportLab Paragraph tags."""
    t = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    code_blocks = []
    def _save_code(m):
        idx = len(code_blocks)
        code_blocks.append(m.group(1))
        return f"__CODE_PH_{idx}__"
    t = re.sub(r'`([^`]+)`', _save_code, t)

    t = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<!\*)\*([A-Za-z0-9_ -]+)\*(?!\*)', r'<i>\1</i>', t)

    for i, cb in enumerate(code_blocks):
        if is_header:
            t = t.replace(f"__CODE_PH_{i}__", f'<font name="Courier"><b>{cb}</b></font>')
        else:
            t = t.replace(f"__CODE_PH_{i}__", f'<font name="Courier" size="7.5" color="#0F172A"><b>{cb}</b></font>')
    return t


def _safe_paragraph(text: str, style, is_header: bool = False):
    """Safely builds a ReportLab Paragraph, falling back to clean escaped text on parse error."""
    try:
        return Paragraph(_format_inline_pdf_markdown(text, is_header), style)
    except Exception:
        clean = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        try:
            return Paragraph(clean, style)
        except Exception:
            return Preformatted(text, style)


def render_mermaid_fallback_pdf(story, code_lines, th_style, td_style, avail_width):
    """Renders a structured process table in PDF when no diagram image is provided."""
    raw_code = "\n".join(code_lines)
    stages, transitions = parse_mermaid_summary(raw_code)

    rows = [["Component / Stage", "Type / Layer", "Action & Flow Destination"]]
    if transitions:
        for src, edge, dst in transitions:
            rows.append([src, "Process Flow Step", f"Progresses to: {dst} ({edge})"])
    elif stages:
        for st_name, nodes in stages:
            rows.append([st_name, "Architectural Group", ", ".join(nodes)])
    else:
        rows.append(["Application Lifecycle", "Process Automation", "System workflow execution path"])

    table_data = []
    for r_idx, r_data in enumerate(rows):
        is_h = (r_idx == 0)
        st = th_style if is_h else td_style
        table_data.append([
            Paragraph(_format_inline_pdf_markdown(c, is_h), st)
            for c in r_data
        ])

    col_w = [avail_width * 0.35, avail_width * 0.25, avail_width * 0.40]
    t = Table(table_data, colWidths=col_w, repeatRows=1)
    t_style = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E293B")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 3.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
        ("LEFTPADDING", (0, 0), (-1, -1), 4.5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4.5),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
        ("BOX", (0, 0), (-1, -1), 0.75, colors.HexColor("#94A3B8")),
    ]
    for r_idx in range(1, len(rows)):
        bg = colors.HexColor("#F8FAFC") if r_idx % 2 == 1 else colors.white
        t_style.append(("BACKGROUND", (0, r_idx), (-1, r_idx), bg))
    t.setStyle(TableStyle(t_style))
    story.append(t)
    story.append(Spacer(1, 8))


def markdown_to_pdf(markdown_text: str, diagrams: list = None) -> io.BytesIO:
    """Converts Markdown text into a styled, professional PDF using ReportLab with clean Deluge code blocks and embedded flowchart diagrams."""
    markdown_text = sanitize_export_text(markdown_text)
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=1.5 * cm,
        rightMargin=1.5 * cm,
        topMargin=1.5 * cm,
        bottomMargin=1.5 * cm,
    )
    styles = getSampleStyleSheet()
    avail_width = A4[0] - 2 * 1.5 * cm

    title_style = ParagraphStyle(
        "DocTitle",
        parent=styles["Heading1"],
        fontName="Helvetica-Bold",
        fontSize=16,
        leading=20,
        textColor=colors.HexColor("#0F172A"),
        spaceAfter=10,
        spaceBefore=12,
        keepWithNext=True
    )
    h2_style = ParagraphStyle(
        "DocH2",
        parent=styles["Heading2"],
        fontName="Helvetica-Bold",
        fontSize=12.5,
        leading=16,
        textColor=colors.HexColor("#1E293B"),
        spaceAfter=6,
        spaceBefore=10,
        keepWithNext=True
    )
    h3_style = ParagraphStyle(
        "DocH3",
        parent=styles["Heading3"],
        fontName="Helvetica-Bold",
        fontSize=10,
        leading=13.5,
        textColor=colors.HexColor("#334155"),
        spaceAfter=4,
        spaceBefore=7,
        keepWithNext=True
    )
    body_style = ParagraphStyle(
        "DocBody",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=8.5,
        leading=12,
        textColor=colors.HexColor("#1E293B"),
        spaceAfter=4
    )
    bullet_style = ParagraphStyle(
        "DocBullet",
        parent=body_style,
        leftIndent=14,
        firstLineIndent=-9,
        spaceAfter=2
    )
    num_list_style = ParagraphStyle(
        "DocNumList",
        parent=body_style,
        leftIndent=16,
        firstLineIndent=-12,
        spaceAfter=2
    )
    code_style = ParagraphStyle(
        "DocCode",
        fontName="Courier",
        fontSize=7,
        leading=9.5,
        textColor=colors.HexColor("#0F172A"),
        backColor=colors.HexColor("#F8FAFC"),
        borderColor=colors.HexColor("#E2E8F0"),
        borderWidth=0.5,
        borderPadding=5,
        spaceBefore=4,
        spaceAfter=6
    )
    th_style = ParagraphStyle(
        "THStyle",
        fontName="Helvetica-Bold",
        fontSize=7.5,
        leading=9.5,
        textColor=colors.white,
        alignment=0
    )
    td_style = ParagraphStyle(
        "TDStyle",
        fontName="Helvetica",
        fontSize=7,
        leading=9,
        textColor=colors.HexColor("#1E293B"),
        alignment=0
    )

    story = []
    lines = markdown_text.splitlines()
    in_code = False
    code_block = []
    code_lang = ""
    mermaid_counter = 0
    in_table = False
    table_lines = []

    def flush_table():
        nonlocal in_table, table_lines
        if not table_lines:
            in_table = False
            return

        rows = []
        for line in table_lines:
            cleaned = line.strip()
            if re.match(r"^\|?\s*:?-+:?\s*(\|?\s*:?-+:?\s*)+\|?$", cleaned):
                continue
            raw_cells = cleaned.split("|")
            if cleaned.startswith("|"):
                raw_cells = raw_cells[1:]
            if cleaned.endswith("|") and raw_cells:
                raw_cells = raw_cells[:-1]
            cells = [c.strip() for c in raw_cells]
            if cells and any(c for c in cells):
                rows.append(cells)

        table_lines = []
        in_table = False

        if not rows:
            return

        max_cols = max(len(r) for r in rows)
        for r in rows:
            while len(r) < max_cols:
                r.append("")

        col_lens = [0] * max_cols
        for row in rows:
            for i, c in enumerate(row):
                plain = re.sub(r"[*`_#]", "", c).strip()
                col_lens[i] = max(col_lens[i], len(plain))

        col_weights = [max(l, 8) for l in col_lens]
        tot = sum(col_weights)
        col_widths = [(w / tot) * avail_width for w in col_weights]

        min_w = 40.0
        if max_cols * min_w <= avail_width:
            adjusted = list(col_widths)
            for _ in range(3):
                deficit = sum(max(0, min_w - w) for w in adjusted)
                if deficit <= 0:
                    break
                surplus = sum(w for w in adjusted if w > min_w)
                if surplus > 0:
                    for i in range(max_cols):
                        if adjusted[i] > min_w:
                            adjusted[i] -= deficit * (adjusted[i] / surplus)
                        else:
                            adjusted[i] = min_w
            col_widths = adjusted

        table_data = []
        for r_idx, row in enumerate(rows):
            is_header = (r_idx == 0)
            row_flowables = []
            for cell_str in row:
                st = th_style if is_header else td_style
                row_flowables.append(Paragraph(_format_inline_pdf_markdown(cell_str, is_header), st))
            table_data.append(row_flowables)

        t = Table(table_data, colWidths=col_widths, repeatRows=1)
        t_style = [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E293B")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 3.5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
            ("LEFTPADDING", (0, 0), (-1, -1), 4.5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4.5),
            ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
            ("BOX", (0, 0), (-1, -1), 0.75, colors.HexColor("#94A3B8")),
        ]
        for r_idx in range(1, len(rows)):
            bg = colors.HexColor("#F8FAFC") if r_idx % 2 == 1 else colors.white
            t_style.append(("BACKGROUND", (0, r_idx), (-1, r_idx), bg))

        t.setStyle(TableStyle(t_style))
        story.append(t)
        story.append(Spacer(1, 8))

    def flush_code():
        nonlocal in_code, code_block, code_lang, mermaid_counter
        if not code_block and code_lang != "mermaid":
            in_code = False
            return

        if code_lang == "mermaid":
            matched_diag = find_matching_diagram(mermaid_counter, code_block, diagrams)
            mermaid_counter += 1
            if matched_diag and matched_diag.get("image"):
                try:
                    img_bytes = decode_base64_image(matched_diag["image"])
                    pil_img = PILImage.open(io.BytesIO(img_bytes))
                    if pil_img.mode in ("RGBA", "LA") or (pil_img.mode == "P" and "transparency" in pil_img.info):
                        bg = PILImage.new("RGB", pil_img.size, (255, 255, 255))
                        if pil_img.mode == "P":
                            pil_img = pil_img.convert("RGBA")
                        bg.paste(pil_img, mask=pil_img.split()[3])
                        out_io = io.BytesIO()
                        bg.save(out_io, format="PNG")
                        img_bytes = out_io.getvalue()
                        pil_img = bg

                    w, h = pil_img.size
                    scale = min(avail_width / float(w), 1.0)
                    target_w = w * scale
                    target_h = h * scale
                    max_h = 420.0
                    if target_h > max_h:
                        h_scale = max_h / target_h
                        target_w *= h_scale
                        target_h = max_h

                    story.append(Spacer(1, 6))
                    story.append(RLImage(io.BytesIO(img_bytes), width=target_w, height=target_h))

                    caption_style = ParagraphStyle(
                        "PdfCaption",
                        parent=body_style,
                        fontName="Helvetica-Oblique",
                        fontSize=7.5,
                        leading=9.5,
                        textColor=colors.HexColor("#64748B"),
                        alignment=1,
                        spaceBefore=3,
                        spaceAfter=8
                    )
                    story.append(Paragraph("<b>Figure:</b> Interactive Architecture Process & Lifecycle Flowchart", caption_style))
                    story.append(Spacer(1, 8))

                    code_block = []
                    in_code = False
                    return
                except Exception as img_err:
                    print(f"Error embedding chart image in PDF: {img_err}", flush=True)

            # Fallback for PDF: render structured table instead of raw code
            render_mermaid_fallback_pdf(story, code_block, th_style, td_style, avail_width)
            code_block = []
            in_code = False
            return

        # Clean, indent, and format non-mermaid code block (zero tabs, zero black dots)
        formatted_code = clean_and_format_code(code_block, code_lang)
        if formatted_code:
            wrapped_lines = []
            for line in formatted_code.splitlines():
                if len(line) <= 85:
                    wrapped_lines.append(line)
                else:
                    chunks = textwrap.wrap(line, width=85, subsequent_indent="    ", break_long_words=True, break_on_hyphens=False)
                    wrapped_lines.extend(chunks)
            joined_code = "\n".join(wrapped_lines)
            story.append(Preformatted(joined_code, code_style))
            story.append(Spacer(1, 6))

        code_block = []
        in_code = False

    for line in lines:
        stripped = line.strip()

        # Handle Code Blocks
        if stripped.startswith("```"):
            if in_code:
                flush_code()
            else:
                if in_table:
                    flush_table()
                in_code = True
                code_lang = stripped[3:].strip().lower()
                code_block = []
            continue

        if in_code:
            code_block.append(line)
            continue

        # Handle Tables
        if stripped.startswith("|") and ("|" in stripped[1:]):
            in_table = True
            table_lines.append(stripped)
            continue
        elif in_table:
            flush_table()

        if not stripped:
            continue

        # Horizontal Divider
        if re.match(r"^(\*{3,}|-{3,}|_{3,})$", stripped):
            story.append(HRFlowable(width="100%", thickness=0.75, color=colors.HexColor("#CBD5E1"), spaceBefore=6, spaceAfter=8))
            continue

        # Headings
        if stripped.startswith("# "):
            title_text = re.sub(r"^#+\s*", "", stripped)
            story.append(_safe_paragraph(title_text, title_style, is_header=True))
        elif stripped.startswith("## "):
            h2_text = re.sub(r"^#+\s*", "", stripped)
            story.append(_safe_paragraph(h2_text, h2_style, is_header=True))
        elif stripped.startswith("### "):
            h3_text = re.sub(r"^#+\s*", "", stripped)
            story.append(_safe_paragraph(h3_text, h3_style, is_header=True))
        elif stripped.startswith("- ") or stripped.startswith("* "):
            content = stripped[2:].strip()
            bullet_html = f"&bull;  {_format_inline_pdf_markdown(content)}"
            try:
                story.append(Paragraph(bullet_html, bullet_style))
            except Exception:
                story.append(_safe_paragraph(content, bullet_style))
        elif re.match(r"^\d+\.\s+", stripped):
            m = re.match(r"^(\d+)\.\s+(.*)$", stripped)
            num = m.group(1)
            content = m.group(2)
            num_html = f"<b>{num}.</b>  {_format_inline_pdf_markdown(content)}"
            try:
                story.append(Paragraph(num_html, num_list_style))
            except Exception:
                story.append(_safe_paragraph(f"{num}. {content}", num_list_style))
        else:
            story.append(_safe_paragraph(stripped, body_style))

    if in_table:
        flush_table()
    if in_code:
        flush_code()

    doc.build(story)
    buffer.seek(0)
    return buffer
